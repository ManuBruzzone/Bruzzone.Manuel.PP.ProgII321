
package expedicionesespaciales;


public class NaveExploracion extends Nave implements Explorar{
    private TipoMision tipoMision;
    
    public NaveExploracion(String nombre, int capacidadDeTripulacion, int añoDeLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadDeTripulacion, añoDeLanzamiento);
        this.tipoMision = tipoMision;
    }
    
    @Override
    public void explorar() {
        System.out.println("Se esta explorando con la Nave de exploracion " + getNombre());
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Tipo de mision: " + tipoMision + "}";
    }

}