
package expedicionesespaciales;


public class YaExisteLaNaveException extends RuntimeException{
    private static final String MESSAGE = "La Nave ya existe!";
    
    public YaExisteLaNaveException(){
        super(MESSAGE);
    }
}