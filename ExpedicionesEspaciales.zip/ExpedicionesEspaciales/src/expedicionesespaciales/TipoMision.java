
package expedicionesespaciales;


public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
