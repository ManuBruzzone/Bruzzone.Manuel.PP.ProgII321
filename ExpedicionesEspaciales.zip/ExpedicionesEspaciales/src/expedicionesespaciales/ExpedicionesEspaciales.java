
package expedicionesespaciales;

import java.util.Scanner;


public class ExpedicionesEspaciales {


    public static void main(String[] args) {
        Agencia agencia = new Agencia();
        
        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;

        if (continuar) {
            System.out.println("Seleccione una opcion:");
            System.out.println("1. Cargar naves sin errores");
            System.out.println("2. Cargar naves con repetidos");
            System.out.println("3. Cargar naves con error en Crucero Estelar");
            System.out.println("4. Cargar naves con error en Cargero");
            System.out.println("5. Salir");
            System.out.println("Ingrese su opcion: ");

            int opcion;
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    try {
                        System.out.println("--Bloque sin errores--");
                        agencia.agregarNave(new Cargero("Perla Voladora", 300, 2000, 200));
                        agencia.agregarNave(new Cargero("Rocker Truck", 500, 1950, 450));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 450));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | YaExisteLaNaveException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;
                    
                case 2:
                    try {
                        System.out.println("--Bloque con repetidos--");
                        agencia.agregarNave(new Cargero("Galáctica", 300, 2020, 200));
                        agencia.agregarNave(new Cargero("Rocker Truck", 500, 1950, 450));
                        agencia.agregarNave(new CruceroEstelar("Galáctica", 700, 2020, 450));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 450));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Galáctica", 25, 2020, TipoMision.CONTACTO));
                    } catch (NullPointerException | YaExisteLaNaveException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        System.out.println("--Bloque con error en Crucero Estelar--");
                        agencia.agregarNave(new Cargero("Perla Voladora", 300, 2000, 200));
                        agencia.agregarNave(new Cargero("Rocker Truck", 500, 1950, 450));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, -1));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | YaExisteLaNaveException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;
                    
                case 4:
                    try {
                        System.out.println("--Bloque con error en Crucero Estelar--");
                        agencia.agregarNave(new Cargero("Perla Voladora", 300, 2000, 453));
                        agencia.agregarNave(new Cargero("Rocker Truck", 500, 1950, 4600));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 300));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | YaExisteLaNaveException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;

                case 5:
                    continuar = false;
                    break;
            }
        }

        System.out.println("--------------------------------------------------------------");
        agencia.mostrarNaves();
        System.out.println("--------------------------------------------------------------");
        agencia.iniciarExploracion();
    }
}
