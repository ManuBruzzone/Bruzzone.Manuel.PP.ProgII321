
package expedicionesespaciales;

import java.util.ArrayList;
import java.util.List;


public class Agencia {
    private List<Nave> naves;

    public Agencia() {
        this.naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave nave){
        if(nave == null){
            throw new NullPointerException("Valor nulo.");
        }
        if(!yaExiste(nave)){   
            naves.add(nave);
            System.out.println("Se agrego la nave: " + nave.getNombre() + " a la agencia.");   
        }
    }
    
    private boolean yaExiste(Nave nave){
        if (naves.contains(nave)) {
            throw new YaExisteLaNaveException();
        }
        return false;
    }
    
    public void mostrarNaves() {
        for (Nave nave : naves) {
            System.out.println(nave);
        }
    }
    
    public void iniciarExploracion(){
    for(Nave nave: naves){
            if(nave instanceof Explorar explorar){
                explorar.explorar();
            }
            else{
                System.out.println("La nave " + nave.getNombre()+ " no puede explorar." );
            }
        }
    }
}