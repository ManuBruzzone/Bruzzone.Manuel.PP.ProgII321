package expedicionesespaciales;

public class CruceroEstelar extends Nave {

    private int capacidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadDeTripulacion, int añoDeLanzamiento, int capacidadPasajeros) {
        super(nombre, capacidadDeTripulacion, añoDeLanzamiento);
        if (capacidadPasajeros < 0) {
            throw new IllegalArgumentException("La capacidad de Pasajeros no puede ser negativa");
        }
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public String toString() {
        return super.toString() + ", Capacidad de pasajeros: " + capacidadPasajeros + "}";
    }
}