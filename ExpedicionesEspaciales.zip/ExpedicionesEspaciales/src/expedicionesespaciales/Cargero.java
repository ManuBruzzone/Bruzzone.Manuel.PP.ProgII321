package expedicionesespaciales;

public class Cargero extends Nave implements Explorar {

    public static final int MAX_CARGA = 500;
    public static final int MIN_CARGA = 100;

    private double capacidadCarga;

    public Cargero(String nombre, int capacidadDeTripulacion, int añoDeLanzamiento, double capacidadCarga) {
        super(nombre, capacidadDeTripulacion, añoDeLanzamiento);

        if (capacidadCarga < MIN_CARGA || capacidadCarga > MAX_CARGA) {
            throw new IllegalArgumentException("La capacidad de carga debe estar entre " + MIN_CARGA + " y " + MAX_CARGA + " toneladas.");
        }

        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println("Se esta explorando con el Cargero " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + ", Capacidad de carga: " + capacidadCarga + " Toneladas}";
    }
}
