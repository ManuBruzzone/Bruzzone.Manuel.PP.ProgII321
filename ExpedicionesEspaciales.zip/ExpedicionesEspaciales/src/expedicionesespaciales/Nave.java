
package expedicionesespaciales;

import java.util.Objects;


public abstract class Nave {
    private String nombre;
    private int capacidadDeTripulacion;
    private int añoDeLanzamiento;

    public Nave(String nombre, int capacidadDeTripulacion, int añoDeLanzamiento) {
        this.nombre = nombre;
        this.capacidadDeTripulacion = capacidadDeTripulacion;
        this.añoDeLanzamiento = añoDeLanzamiento;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        Nave other = (Nave) o;

        return other.añoDeLanzamiento == añoDeLanzamiento
                && other.nombre.equals(nombre);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(añoDeLanzamiento, nombre);
    }

    protected String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre: " + nombre + ", capacidad de tripulacion: " + capacidadDeTripulacion + ", anio de lanzamiento: " + añoDeLanzamiento;
    }
    
    
    
}
